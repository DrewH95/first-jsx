import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'

function App() {
  return (
    <div className="container">
      <h1>Hello Dojo!</h1>
      <h3>Things I need to do:</h3>
      <ul>
        <li>Learn React</li>
        <li>Find a 34" monitor</li>
        <li>Pay bills</li>
        <li>Go to the gym!!!</li>
      </ul>
    </div>
  );
}

export default App;
